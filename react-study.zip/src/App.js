import React from 'react';
import './App.css';
import ExpenseItem from './components/ExpenseItem';

const App = () => {
  return (
    <>
      <ExpenseItem
        title='샤인머스캣'
        price={20000}
        date={new Date(2023, 3, 23)}
      />
      <ExpenseItem
        title='BBQ 치킨'
        price={35000}
        date={new Date(2023, 6, 2)}
      />
      <ExpenseItem
        title='도미노 피자'
        price={30000}
        date={new Date(2023, 4, 18)}
      />
    </>
  );
};

export default App;
