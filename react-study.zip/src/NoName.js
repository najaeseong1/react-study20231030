import React from 'react';

class NoName extends React.Component {
  render() {
    return (
      <div className='wrap'>
        <h1>NoName</h1>
      </div>
    );
  }
}

export default NoName;
